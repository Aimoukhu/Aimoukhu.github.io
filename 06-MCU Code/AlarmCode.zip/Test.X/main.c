#include "mcc_generated_files/system/system.h"
#include <xc.h>

// =======================================================
// SIMPLE SIREN USING DAC1 (
// =======================================================
int8_t direction;
uint8_t dacValue=0;
int8_t stepSize=5 ;

void Siren_Update(void)
{
    // direction = 1 ? HIGH
    // direction = 0 ? LOW

    if (direction == 1)
    {
        dacValue = 100    ;     // HIGH output
        direction = 0;      // next time go LOW
    }
    else
    {
        dacValue = 10;       // LOW output
        direction = 1;      // next time go HIGH
    }

    DAC1_SetOutput(dacValue);
}


int main(void)
{
    SYSTEM_Initialize();

    // ============================
    // Ensure ALL pins are digital
    // ============================
    DOOR_SetDigitalInput();     DOOR_SetDigitalMode();
    SWITCH_SetDigitalInput();   SWITCH_SetDigitalMode();
    LED_SetDigitalOutput();     LED_SetDigitalMode();
    MOTOR_SetDigitalOutput();   MOTOR_SetDigitalMode();
    SPEAKER_SetDigitalOutput(); // Not used now but keep digital
    SPEAKER_SetDigitalMode();

    uint8_t override = 0;
    uint8_t lastSwitch = SWITCH_GetValue();

    uint8_t lastDoor = DOOR_GetValue();   // track door transitions

    while(1)
    {
        // ==================================
        // SWITCH TOGGLE EDGE DETECTION
        // ==================================
        uint8_t now = SWITCH_GetValue();

        if (now != lastSwitch)
        {
            __delay_ms(20); // debounce

            if (now == SWITCH_GetValue())
            {
                if (now == 1)  // pull-down button: HIGH = pressed
                {
                    override ^= 1;   // toggle state

                    // Instant override response
                    LED_SetLow();
                    DAC1_SetOutput(0);
                }
            }
        }

        lastSwitch = now;


        // ==================================
        // MOTOR OUTPUT BASED ON OVERRIDE
        // ==================================
        if (override == 1)
            MOTOR_SetHigh();     // override ON ? motor HIGH
        else
            MOTOR_SetLow();      // override OFF ? motor LOW


        // ==================================
        // OVERRIDE ENABLED ? EVERYTHING OFF
        // ==================================
        if (override == 1)
        {
            LED_SetLow();
            DAC1_SetOutput(0);
            continue;
        }


        // ==================================
        // DOOR CLOSED ? EVERYTHING OFF
        // ==================================
        uint8_t doorNow = DOOR_GetValue();

        if (doorNow == 0)
        {
            LED_SetLow();
            DAC1_SetOutput(0);
            lastDoor = 0;
            continue;
        }


        // ==================================
        // DOOR JUST OPENED ? INSTANT SIREN START
        // ================================== 
        if (lastDoor == 0 && doorNow == 1)
        {
            DAC1_SetOutput(0);  // ensure siren begins immediately
        }

        lastDoor = 1;


        // ==================================
        // DOOR OPEN ? LED ON + DAC SIREN
        // ==================================
        LED_SetHigh();

        // Update DAC waveform every loop
        Siren_Update();

        __delay_us(10  );   // small loop tick for smooth siren
    }
}
