/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA2 aliases
#define DAC1_TRIS                 TRISAbits.TRISA2
#define DAC1_LAT                  LATAbits.LATA2
#define DAC1_PORT                 PORTAbits.RA2
#define DAC1_WPU                  WPUAbits.WPUA2
#define DAC1_OD                   ODCONAbits.ODCA2
#define DAC1_ANS                  ANSELAbits.ANSELA2
#define DAC1_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define DAC1_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define DAC1_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define DAC1_GetValue()           PORTAbits.RA2
#define DAC1_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define DAC1_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define DAC1_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define DAC1_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define DAC1_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define DAC1_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define DAC1_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define DAC1_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RC7 aliases
#define SWITCH_TRIS                 TRISCbits.TRISC7
#define SWITCH_LAT                  LATCbits.LATC7
#define SWITCH_PORT                 PORTCbits.RC7
#define SWITCH_WPU                  WPUCbits.WPUC7
#define SWITCH_OD                   ODCONCbits.ODCC7
#define SWITCH_ANS                  ANSELCbits.ANSELC7
#define SWITCH_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define SWITCH_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define SWITCH_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define SWITCH_GetValue()           PORTCbits.RC7
#define SWITCH_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define SWITCH_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define SWITCH_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define SWITCH_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define SWITCH_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define SWITCH_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define SWITCH_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define SWITCH_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

// get/set RD2 aliases
#define SPEAKER_TRIS                 TRISDbits.TRISD2
#define SPEAKER_LAT                  LATDbits.LATD2
#define SPEAKER_PORT                 PORTDbits.RD2
#define SPEAKER_WPU                  WPUDbits.WPUD2
#define SPEAKER_OD                   ODCONDbits.ODCD2
#define SPEAKER_ANS                  ANSELDbits.ANSELD2
#define SPEAKER_SetHigh()            do { LATDbits.LATD2 = 1; } while(0)
#define SPEAKER_SetLow()             do { LATDbits.LATD2 = 0; } while(0)
#define SPEAKER_Toggle()             do { LATDbits.LATD2 = ~LATDbits.LATD2; } while(0)
#define SPEAKER_GetValue()           PORTDbits.RD2
#define SPEAKER_SetDigitalInput()    do { TRISDbits.TRISD2 = 1; } while(0)
#define SPEAKER_SetDigitalOutput()   do { TRISDbits.TRISD2 = 0; } while(0)
#define SPEAKER_SetPullup()          do { WPUDbits.WPUD2 = 1; } while(0)
#define SPEAKER_ResetPullup()        do { WPUDbits.WPUD2 = 0; } while(0)
#define SPEAKER_SetPushPull()        do { ODCONDbits.ODCD2 = 0; } while(0)
#define SPEAKER_SetOpenDrain()       do { ODCONDbits.ODCD2 = 1; } while(0)
#define SPEAKER_SetAnalogMode()      do { ANSELDbits.ANSELD2 = 1; } while(0)
#define SPEAKER_SetDigitalMode()     do { ANSELDbits.ANSELD2 = 0; } while(0)

// get/set RE0 aliases
#define MOTOR_TRIS                 TRISEbits.TRISE0
#define MOTOR_LAT                  LATEbits.LATE0
#define MOTOR_PORT                 PORTEbits.RE0
#define MOTOR_WPU                  WPUEbits.WPUE0
#define MOTOR_OD                   ODCONEbits.ODCE0
#define MOTOR_ANS                  ANSELEbits.ANSELE0
#define MOTOR_SetHigh()            do { LATEbits.LATE0 = 1; } while(0)
#define MOTOR_SetLow()             do { LATEbits.LATE0 = 0; } while(0)
#define MOTOR_Toggle()             do { LATEbits.LATE0 = ~LATEbits.LATE0; } while(0)
#define MOTOR_GetValue()           PORTEbits.RE0
#define MOTOR_SetDigitalInput()    do { TRISEbits.TRISE0 = 1; } while(0)
#define MOTOR_SetDigitalOutput()   do { TRISEbits.TRISE0 = 0; } while(0)
#define MOTOR_SetPullup()          do { WPUEbits.WPUE0 = 1; } while(0)
#define MOTOR_ResetPullup()        do { WPUEbits.WPUE0 = 0; } while(0)
#define MOTOR_SetPushPull()        do { ODCONEbits.ODCE0 = 0; } while(0)
#define MOTOR_SetOpenDrain()       do { ODCONEbits.ODCE0 = 1; } while(0)
#define MOTOR_SetAnalogMode()      do { ANSELEbits.ANSELE0 = 1; } while(0)
#define MOTOR_SetDigitalMode()     do { ANSELEbits.ANSELE0 = 0; } while(0)

// get/set RF1 aliases
#define LED_TRIS                 TRISFbits.TRISF1
#define LED_LAT                  LATFbits.LATF1
#define LED_PORT                 PORTFbits.RF1
#define LED_WPU                  WPUFbits.WPUF1
#define LED_OD                   ODCONFbits.ODCF1
#define LED_ANS                  ANSELFbits.ANSELF1
#define LED_SetHigh()            do { LATFbits.LATF1 = 1; } while(0)
#define LED_SetLow()             do { LATFbits.LATF1 = 0; } while(0)
#define LED_Toggle()             do { LATFbits.LATF1 = ~LATFbits.LATF1; } while(0)
#define LED_GetValue()           PORTFbits.RF1
#define LED_SetDigitalInput()    do { TRISFbits.TRISF1 = 1; } while(0)
#define LED_SetDigitalOutput()   do { TRISFbits.TRISF1 = 0; } while(0)
#define LED_SetPullup()          do { WPUFbits.WPUF1 = 1; } while(0)
#define LED_ResetPullup()        do { WPUFbits.WPUF1 = 0; } while(0)
#define LED_SetPushPull()        do { ODCONFbits.ODCF1 = 0; } while(0)
#define LED_SetOpenDrain()       do { ODCONFbits.ODCF1 = 1; } while(0)
#define LED_SetAnalogMode()      do { ANSELFbits.ANSELF1 = 1; } while(0)
#define LED_SetDigitalMode()     do { ANSELFbits.ANSELF1 = 0; } while(0)

// get/set RF5 aliases
#define DOOR_TRIS                 TRISFbits.TRISF5
#define DOOR_LAT                  LATFbits.LATF5
#define DOOR_PORT                 PORTFbits.RF5
#define DOOR_WPU                  WPUFbits.WPUF5
#define DOOR_OD                   ODCONFbits.ODCF5
#define DOOR_ANS                  ANSELFbits.ANSELF5
#define DOOR_SetHigh()            do { LATFbits.LATF5 = 1; } while(0)
#define DOOR_SetLow()             do { LATFbits.LATF5 = 0; } while(0)
#define DOOR_Toggle()             do { LATFbits.LATF5 = ~LATFbits.LATF5; } while(0)
#define DOOR_GetValue()           PORTFbits.RF5
#define DOOR_SetDigitalInput()    do { TRISFbits.TRISF5 = 1; } while(0)
#define DOOR_SetDigitalOutput()   do { TRISFbits.TRISF5 = 0; } while(0)
#define DOOR_SetPullup()          do { WPUFbits.WPUF5 = 1; } while(0)
#define DOOR_ResetPullup()        do { WPUFbits.WPUF5 = 0; } while(0)
#define DOOR_SetPushPull()        do { ODCONFbits.ODCF5 = 0; } while(0)
#define DOOR_SetOpenDrain()       do { ODCONFbits.ODCF5 = 1; } while(0)
#define DOOR_SetAnalogMode()      do { ANSELFbits.ANSELF5 = 1; } while(0)
#define DOOR_SetDigitalMode()     do { ANSELFbits.ANSELF5 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/